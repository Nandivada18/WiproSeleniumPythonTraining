n = [10,20,70,40,60]
largest = n[0]
for i in n:
    if i > largest:
        largest = i
print(largest)