#xfail is a marker used to indicate that a test is expected to fail due to a known issue (e.g., a bug or an unimplemented feature)
import pytest
@pytest.mark.xfail(reason="Known bug in the third party library")
def test_function_with_bug():
    assert (1 + 1) == 3#this is assertion will fail as expected

#testcases1
@pytest.mark.sanity
def test_case1():
    print("testcase1 is executed")

#testcases2
@pytest.mark.regression
def test_case2():
    print("testcase2 is executed")

#testcases3
@pytest.mark.db
def test_case3():
    print("testcase3 is executed")
