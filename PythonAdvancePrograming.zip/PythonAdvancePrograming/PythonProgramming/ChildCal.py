import Calculator
print(Calculator.add(1,6))
print(Calculator.sub(5,2))