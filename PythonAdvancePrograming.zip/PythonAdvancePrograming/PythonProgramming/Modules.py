#Moduloe is a file that contains python code - var, functional, classes
#benefits
#code reusability, easier maintainence
#better organization

#built in modules
#user defined modules

#built math
import math
from datetime import datetime
from datetime import date

print(math.sqrt(16))
print(math.pi)

print(datetime.now())
print(date.today())